import click
import subprocess
import os
import re
from config import settings
from kolja_aws.utils import (
    remove_block_from_config, 
    get_latest_token,
)


aws_config = settings.AWS_CONFIG
aws_region = settings.AWS_REGION


@click.group()
def cli():
    """Kolja CLI Tool for improve efficiency with aws."""


@click.group()
def aws():
    """Development commands."""


@click.command()
@click.argument('sso_sessions', nargs=-1)
def set(sso_sessions):
    # sso_sessions=list(sso_sessions)
    for sso_session in sso_sessions:
        if sso_session == "adpn-cn":
            remove_block_from_config(os.path.expanduser(aws_config), f'sso-session {sso_session}')
            with open(os.path.expanduser(aws_config), 'a') as f:
                f.write("""
[sso-session adpn-cn]
sso_start_url = https://start.cn-north-1.home.awsapps.cn/directory/orionadp-cn-prod
sso_region = cn-north-1
sso_registration_scopes = sso:account:access
""")
    

@click.command()
def get():
    with open(os.path.expanduser(aws_config), 'r') as f:
        text = f.read()
    matches = re.findall(r'\[sso-session (\S+)\]', text)
    if matches:
        for sso_session_value in matches:
            print(f"sso_session: {sso_session_value}")


@click.command()
def login():
    # aws sso login --sso-session xxx
    if settings.get("SSO_SESSIONS", None):
        sso_sessions = settings.SSO_SESSIONS
        for i in sso_sessions:

            result = subprocess.run(
                ['aws', 'sso', 'login', '--sso-session', i], 
                capture_output=True, 
                text=True
            )
            
            if result.returncode == 0:
                print(f"Login successful for session: {i}")
            else:
                print(f"Login failed for session: {i}")
                print(f"Error: {result.stderr}")


@click.command()
def profiles():
   latest_token = get_latest_token
   result = subprocess.run(['aws', 'sso', 'login', 'list-accounts',
                    "--access-token", latest_token,
                    "--region", aws_region,
                    "--output", "json",
                ], 
                capture_output=True, 
                text=True
            )


# register command
aws.add_command(login)
aws.add_command(get)
aws.add_command(set)
aws.add_command(profiles)
cli.add_command(aws)

# aws sso list-accounts --access-token  --region cn-north-1 --output json

if __name__ == "__main__":
    cli()

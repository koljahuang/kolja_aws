import configparser
import os
import json
from datetime import datetime


def remove_block_from_config(file_path, section):

    config = configparser.ConfigParser()
    
    config.read(file_path)

    if config.has_section(section):
        config.remove_section(section)
        print(f"removed section: {section}")
    else:
        print(f"section not found: {section}")
    
    with open(file_path, 'w') as config_file:
        config.write(config_file)


def get_latest_token(cache_dir="~/.aws/sso/cache"):
    # Expand the user path
    cache_dir = os.path.expanduser(cache_dir)
    latest_token = None
    latest_time = None

    # Iterate over all JSON files in the directory
    for filename in os.listdir(cache_dir):
        if filename.endswith(".json"):
            filepath = os.path.join(cache_dir, filename)
            try:
                # Load JSON content
                with open(filepath, "r") as f:
                    data = json.load(f)
                
                # Check for valid fields
                expires_at = data.get("expiresAt")
                access_token = data.get("accessToken")
                if expires_at and access_token:
                    # Parse the expiration time
                    expires_at_dt = datetime.fromisoformat(expires_at)
                    
                    # Update the latest token if this one is newer
                    if latest_time is None or expires_at_dt > latest_time:
                        latest_time = expires_at_dt
                        latest_token = access_token
            except Exception as e:
                print(f"Error processing file {filename}: {e}")
    
    return latest_token


if __name__ == "__main__":
    print(get_latest_token())